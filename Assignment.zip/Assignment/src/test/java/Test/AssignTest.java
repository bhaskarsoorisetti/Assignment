package Test;



import java.util.List;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import assign.engine.TestEngine;
import assign.page.HomePage;

public class AssignTest extends TestEngine {
	
	HomePage pgHome=null;
	
	@BeforeClass
	public void beforeClass() {
		pgHome=new HomePage(driver);
	}
	
	@Test
	@Parameters({"SearchCriteria"})
	public void assignment(String searchCriteria) {
		boolean res=false;
		String indexValue="6";
		String priceValue="";
		try {
			//enter text into search field
			res=pgHome.enterText(pgHome.inpSearchField, searchCriteria);
			reportStatus(res,"Successfully entered "+searchCriteria+" in Search Filed","Failed to enter "+searchCriteria+" in Search Filed");

			//clicking search button
			res=pgHome.click(pgHome.btnSearch);
			reportStatus(res,"Successfully clicked search button","Failed to click search button");
	
			//getting all price values from page
		    List<Integer> resList=pgHome.gettingAmounts(pgHome.lblPriceValues);
		    
		    //sorting that price values in descending order and printing 
		    List<Integer> result=pgHome.sortAmount(resList);
			reportStatus.log(Status.INFO, "Sorting of Amount in Descending order is £ "+result);
			pgHome.scrollToViewElement(pgHome.lblPriceValuesIndex.replace("index", indexValue));
			priceValue=pgHome.getVisibleText(pgHome.lblPriceValuesIndex.replace("index", indexValue));
			
			//clicking 5th price element 
			res=pgHome.click(pgHome.lblPriceValuesIndex.replace("index", indexValue));
			reportStatus(res,"Successfully clicked 5th price value","Failed to click 5th price value");
			
			//verifying Agent logo 
			res=pgHome.verifyElementPresent(pgHome.imgAgentLogo);
			reportStatus(res,"Successfully verified Agent Logo ","Failed to verify Agent Logo");
			String agentName=pgHome.getVisibleText(pgHome.lblAgentName);
			reportStatus.log(Status.INFO, "Mentioned Agent Name is "+agentName);
			String agentNumber=pgHome.getVisibleText(pgHome.lblAgentNumber);
			reportStatus.log(Status.INFO, "Mentioned Agent Number is "+agentNumber);
			
			//clicking phone number link
			res=pgHome.click(pgHome.lblAgentName);
			reportStatus(res,"Successfully clicked on Agent Name link","Failed to click Agent Name link");
			
			res=pgHome.verifyElementPresent(pgHome.lblPriceValues, priceValue);
			reportStatus(res,"Successfully verified price value "+priceValue+" in Agent Page", "Failed to verify price value "+priceValue+" in Agent page");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
