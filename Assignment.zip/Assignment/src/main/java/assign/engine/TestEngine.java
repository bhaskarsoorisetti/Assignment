package assign.engine;

import java.io.File;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;


public class TestEngine {
	
	public WebDriver driver=null;
	public String strProjDirPath = System.getProperty("user.dir");
	public String htmlReportPath=System.getProperty("user.dir")+ File.separator + "Reports" + File.separator+"TestReport.html";
	public String chromeDriverPath=System.getProperty("user.dir")+ File.separator + "Tools" + File.separator + "chromedriver.exe";
	public String firefoxDriverPath=System.getProperty("user.dir")+ File.separator + "Tools" + File.separator + "geckodriver.exe";
	public String projectUrl="https://www.zoopla.co.uk/";
	public ExtentHtmlReporter htmlReporter;
	public ExtentReports report=null;
	public ExtentTest reportStatus=null;
	
	
	@BeforeSuite(alwaysRun = true)
	@Parameters({"BrowserName"})
	public void launchBrowser(String browserUnderTest) throws InterruptedException {
		
		switch ( browserUnderTest.trim().toLowerCase() ){
		
		case "chrome":
			System.setProperty("webdriver.chrome.driver",chromeDriverPath);
			driver=new ChromeDriver();
			break;
		case "firefox":		
			System.setProperty("webdriver.gecko.driver",firefoxDriverPath);
			driver=new FirefoxDriver();
			break;
			
		default:
				break;
			
		}
		loadApplication();
		
	}
	
	public void loadApplication() {
		driver.get(projectUrl);
	}
	
	@BeforeTest(alwaysRun=true)
	public void reportLog() {
		htmlReporter=new ExtentHtmlReporter(htmlReportPath);
		report=new ExtentReports();
		report.attachReporter(htmlReporter);
		report.setSystemInfo("Host Name", "Assignment");
		report.setSystemInfo("Environment", "Automation Testing");
		report.setSystemInfo("User Name", "Bhaskar S");		
		htmlReporter.config().setDocumentTitle("Assignment");
		htmlReporter.config().setReportName("Test");
		htmlReporter.config().setTheme(Theme.STANDARD);
		reportStatus=report.createTest("Assignment Test");
	}

	@AfterTest(alwaysRun=true)
	public void generateReport() {
		report.flush();
		
	}
	
	public void reportStatus(boolean res,String successMsg,String failedMsg) {
		if(res) {
			reportStatus.log(Status.PASS,successMsg );
		}else {
			reportStatus.log(Status.FAIL,failedMsg);
		}
	}
	@AfterSuite(alwaysRun=true)
	public void closeDriver() {
		driver.quit();
	}
	
	public static void main (String[] args) throws InterruptedException {
		TestEngine test=new TestEngine();
		test.launchBrowser("chrome");
	}
}
