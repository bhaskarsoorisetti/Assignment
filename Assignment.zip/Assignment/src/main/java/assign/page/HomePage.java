package assign.page;



import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import javax.swing.Action;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByLinkText;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import assign.engine.TestEngine;

public class HomePage {
	
	public WebDriver driver=null;
	
	public final String imgHomePageLogo="//a[@id='logo']/img";
	public final String inpSearchField="//input[@id='search-input-location']";
    public final String btnSearch="//button[@id='search-submit']";
    public final String lblSearchContent="//div[@id='content']//div/h1[contains(text(),'Property for sale in')]";
    public final String lblPriceValues="//ul[contains(@class,'listing-results clearfix')]/li//a[@class='listing-results-price text-price']";
    public final String lblPriceValuesIndex="//ul[contains(@class,'listing-results clearfix')]/li[index]//a[@class='listing-results-price text-price']";
    public final String lblAgentPage="//div[@id='dp-sticky-element']/article//div/p[contains(@class,'-pricing__main-price')]";
    public final String imgAgentLogo="//div[contains(@class,'__contact')]/div[@class='ui-agent']//img";
    public final String lblAgentName="//div[contains(@class,'__contact')]/div[@class='ui-agent']//h4";
    public final String lblAgentNumber="//div[contains(@class,'__contact')]/div[@class='ui-agent']//a[@class='ui-link']";
    
    public HomePage(WebDriver testDriver) {
    	driver=testDriver;
    }
    
    public boolean enterText(String locator,String text) {
    	boolean res=false;
    	try {
    		WebElement ele=this.driver.findElement(By.xpath(locator));
    		ele.sendKeys(text);
    		if(ele.getAttribute("value").trim().equals(text)) {
    			res=true;
    		}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return res;
    }
    
    public boolean click(String locator) {
    	boolean res=false;
    	try {
    		WebElement ele=this.driver.findElement(By.xpath(locator));
    		ele.click();
    		res=true;
    		Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return res;
    }
    
    public List<Integer> sortAmount(List<Integer> res) {
    	Collections.sort(res,Collections.reverseOrder());
    	System.out.println(res);
    	return res;
    }
    
    public List<Integer> gettingAmounts(String locator){
    	List<Integer> res=new ArrayList<>();
    	String eleName=null;
    	try {
			List<WebElement> elements=this.driver.findElements(By.xpath(locator));
			for(int i=0;i<elements.size();i++) {
				eleName=elements.get(i).getText().replaceAll("[£ a-z A-Z ,]", "");
				if(!eleName.equals("")) {
					res.add(Integer.parseInt(eleName));	
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return res;
    }
    
    public String getVisibleText(String locator) {
    	String result="";
    	try {
    		WebElement ele=this.driver.findElement(By.xpath(locator));
    		result=ele.getText();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return result;
    }
    
    public boolean verifyElementPresent(String locator) {
    	boolean result=false;
    	try {
    		WebElement ele=this.driver.findElement(By.xpath(locator));
    		result=ele.isDisplayed();			
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return result;
    }
    
    public boolean verifyElementPresent(String locator,String expectedElement) {
    	boolean res=false;
    	String eleName="";
    	try {
    		List<WebElement> elements=this.driver.findElements(By.xpath(locator));
			for(int i=0;i<elements.size();i++) {
				eleName=elements.get(i).getText();
				if(eleName.equals(expectedElement)) {
					res=true;
					break;
				}		
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return res;
    }
    
    public void scrollToViewElement(String locator) {
    	try {
    		WebElement ele=this.driver.findElement(By.xpath(locator));
			Actions act=new Actions(this.driver);
			act.moveToElement(ele).build().perform();
			Thread.sleep(2000);
		} catch (Exception e) {
			// TODO: handle exception
		}
    }
}
